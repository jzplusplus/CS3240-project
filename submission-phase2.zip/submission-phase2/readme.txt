Your test cases go into "test" directory and your source code go into "src" directory.
Please read reademe.txt in each directory to see how to fill the directories.
