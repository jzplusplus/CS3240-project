#!/bin/bash
cd ../../src
java test/InterpreterLL1Test ../test/test1/script.txt ../test/test1/grammar.txt ../test/test1/