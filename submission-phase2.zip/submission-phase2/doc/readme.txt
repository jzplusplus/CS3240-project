Put your documentation here.
Your documentation includes:

1) Whether you did the bonus part (using LL(1) parser)
2) Each of your team member's contribution

Do not state how to build / run your program in the documentation.
Your program will be judged by the scripts in your test directory. (see reademe in test directory for more details)
