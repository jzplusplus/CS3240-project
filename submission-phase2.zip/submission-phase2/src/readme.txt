Put all your source code here.
Provide ./build.sh that builds all your code.
You should show the compiler output while ./build.sh is running. (use set -v as in the provided build.sh) 
