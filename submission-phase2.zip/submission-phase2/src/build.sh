set -v
javac test/InterpreterLL1Test.java
#javac test/InterpreterTest.java