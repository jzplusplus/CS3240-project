package exception;

public class EOFException extends Exception {
	public EOFException() {}
}
